<?php
  session_start();
  include('db.php');

  #check unfinished order
  $sql = "UPDATE ordermain SET complete = 4 WHERE DATE(date) != DATE(now()) AND complete != 3 AND complete != 5";
  if($rs = mysqli_query($con, $sql)){
      #echo "success";
  }
  else{
      #echo "failed";
  }

?>
<!DOCTYPE html>
<html>
<head>
  <link rel="shortcut icon" href="images/favicon.png" type="">
  <title>未完成訂單</title>
  <link rel="icon" href="">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="Mystyle.css">
  <link href="css/style.css" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">

</head>
<body style="font-family:NSimSun">
<div class="wrapper">
  <nav class="navbar navbar-expand-md navbar-dark bg-dark" style="position: fixed; width: 100%;z-index:10">
      <a class="navbar-brand" href="manage.php" style="font-family:NSimSun">方禾食呂訂單管理</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav" style="font-family:NSimSun">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="unfinished.php">未完成訂單<span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="finished.php">已完成訂單</a>
          </li>
         
        </ul>
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="manage.php">首頁</a>
          </li>
        </ul>
      </div>
  </nav>
<br>
<br>
<br>
<div class="container">
<h2 style="font-family:NSimSun"><b>未完成訂單</b></h2>
<hr>

<br/>
<table class="table table-bordered data-table">
  <thead>
      <th style='width:50px'>訂單編號</th>
      <th style='width:50px'>取餐號碼</th>
      <th style='width:200px'>餐點名稱</th>
      <th style='width:100px'>醬料</th>
      <th style='width:85px'>副餐</th>
      <th style='width:50px'>特殊類別</th>
      <th style='width:50px'>餐點數量</th>
      <th style='width:70px'>備註</th>
      <th>訂單金額</th>
      <th>使用者名稱</th>
      <th>違規次數</th>
      <th style='width:100px'>日期</th>
      <th>用餐</th>
      <th>狀態</th>
      <th width="100px">狀態更新</th>
      <th width="100px">操作</th>
  </thead>
  <tbody>
    <?php
      $item_count = 0;
      $sql = "SELECT * FROM ordermain";
      $rs = mysqli_query($con, $sql);
      while($row = mysqli_fetch_assoc($rs)){
        if($row['complete'] != 3 && $row['complete'] != 5){
          $item_count += 1;
          echo "<tr>
          <td>".$row['order_id']."</td>
          <td>".$row['rec_num']."</td>
          <td>";#name
        $sqltemp = "SELECT * FROM `orderdetail` WHERE order_id ='".$row['order_id']."'";
        $rstemp = mysqli_query($con, $sqltemp);
        if($rstemp){
          while($rowtemp = mysqli_fetch_assoc($rstemp)){
            $sqlitem = "SELECT `name` FROM item WHERE item_id = ".$rowtemp['item_id']."";
            $rsitem = mysqli_query($con, $sqlitem);
            $rowitem = mysqli_fetch_assoc($rsitem);
            $item_name = $rowitem['name'];
            echo"".$item_name."";
            echo"<br>";
          }
        }
        $place = $row['place'];
        echo "
        </td>
        <td>";#sauce
        $sqltemp = "SELECT * FROM `orderdetail` WHERE order_id ='".$row['order_id']."'";
        $rstemp = mysqli_query($con, $sqltemp);
        if($rstemp){
          while($rowtemp = mysqli_fetch_assoc($rstemp)){
            if($rowtemp['sauce'] != NULL){
              echo $rowtemp['sauce'];
            }
            else{
              echo "無";
            }
            echo"<br>";
          }
        }
        echo"</td>
        <td>";#side
        $sqltemp = "SELECT * FROM `orderdetail` WHERE order_id ='".$row['order_id']."'";
        $rstemp = mysqli_query($con, $sqltemp);
        if($rstemp){
          while($rowtemp = mysqli_fetch_assoc($rstemp)){
            if($rowtemp['side'] != NULL){
              echo $rowtemp['side'];
            }
            else{
              echo "無";
            }
            echo"<br>";
          }
        }
        echo"</td>
        <td>";#variant
        $sqltemp = "SELECT * FROM `orderdetail` WHERE order_id ='".$row['order_id']."'";
        $rstemp = mysqli_query($con, $sqltemp);
        if($rstemp){
          while($rowtemp = mysqli_fetch_assoc($rstemp)){
            if($rowtemp['variant'] != NULL){
              echo $rowtemp['variant'];
            }
            else{
              echo "無";
            }
            echo"<br>";
          }
        }
        echo"</td>
        <td>";#amount
        $sqltemp = "SELECT * FROM `orderdetail` WHERE order_id ='".$row['order_id']."'";
        $rstemp = mysqli_query($con, $sqltemp);
        if($rstemp){
          while($rowtemp = mysqli_fetch_assoc($rstemp)){
            echo $rowtemp['amount']."份";
            echo"<br>";
          }
        }
        echo"</td>
        <td>";#note
        $sqltemp = "SELECT * FROM `orderdetail` WHERE order_id ='".$row['order_id']."'";
        $rstemp = mysqli_query($con, $sqltemp);
        if($rstemp){
          while($rowtemp = mysqli_fetch_assoc($rstemp)){
            if($rowtemp['note'] != NULL){
              echo $rowtemp['note'];
            }
            else{
              echo "無";
            }
            echo"<br>";
          }
        }
        echo"</td>
          <td>$".$row['total_price']."</td>
          <td>".$row['user_id']."</td>
          <td>";
        $sqltemp = "SELECT * FROM `account` WHERE user_id ='".$row['user_id']."'";
        $rstemp = mysqli_query($con, $sqltemp);
        if($rstemp){
          $rowtemp = mysqli_fetch_assoc($rstemp);
          echo $rowtemp['block'];
        }
        echo"
          </td>
          <td>".$row['date']."</td>
          <td>".$place."</td>
          ";
          if($row['complete'] == 0){
            echo "
            <td>訂單未確認</td>
            <td>
              <form action='orderfunc.php' method='post'>
                <input type='hidden' name='id' value='".$row['order_id']."'>
                <input type='hidden' name='func' value='confirm'>
                <input type='submit'  class='btn btn-success btn-xs btn-checkorder'  style='background-color:#88a9c3;border:none;color:white;font-weight:bold;margin-bottom:5px;' value = '確認訂單'>
              </form>
              <form action='orderfunc.php' method='post'>
                <input type='hidden' name='id' value='".$row['order_id']."'>
                <input type='hidden' name='func' value='notify'>
                <input type='submit'  class='btn btn-warning btn-xs btn-notice' style='background-color:#345e7d;border:none;color:white;font-weight:bold'  value = '通知領取'>
              </form>
            </td>
            <td>
              <a href='' data-bs-toggle='modal' data-bs-target='#exampleModal".$row['order_id']."' style='text-decoration: none; color: white;'>
                <button class='btn btn-info btn-xs btn-edit' style='background-color:#2b4257;border:none;color:white;font-weight:bold;margin-bottom:5px;'>編輯訂單</button>
              </a>
              <form action='orderfunc.php' method='post'>
                <input type='hidden' name='id' value='".$row['order_id']."'>
                <input type='hidden' name='func' value='done'>
                <input type='submit'  class='btn btn-warning btn-xs btn-delete' style='background-color:#88a9c3;border:none;color:white;font-weight:bold' value = '完成訂單'>
              </form>
            </td>
            </tr>";
          }
          elseif($row['complete'] == 1){
            echo "
            <td>餐點準備中</td>
            <td>
              <form action='orderfunc.php' method='post'>
                <input type='hidden' name='id' value='".$row['order_id']."'>
                <input type='hidden' name='func' value='notify'>
                <input type='submit'  class='btn btn-success btn-xs btn-notice' style='background-color:#345e7d;border:none;color:white;font-weight:bold'  value = '通知領取'>
              </form>
            </td>
            <td>
              <a href='' data-bs-toggle='modal' data-bs-target='#exampleModal".$row['order_id']."' style='text-decoration: none; color: white;'>
                <button class='btn btn-info btn-xs btn-edit' style='background-color:#2b4257;border:none;color:white;font-weight:bold;margin-bottom:5px;'>編輯訂單</button>
              </a>
              <form action='orderfunc.php' method='post'>
                <input type='hidden' name='id' value='".$row['order_id']."'>
                <input type='hidden' name='func' value='done'>
                <input type='submit'  class='btn btn-warning btn-xs btn-delete' style='background-color:#88a9c3;border:none;color:white;font-weight:bold' value = '完成訂單'>
              </form>
            </td>
            </tr>";
          }
          elseif($row['complete'] == 2){
            echo "
            <td>已完成製作</td>
            <td>
              已通知取餐
            </td>
            <td>
              <a href='' data-bs-toggle='modal' data-bs-target='#exampleModal".$row['order_id']."' style='text-decoration: none; color: white;'>
                <button class='btn btn-info btn-xs btn-edit' style='background-color:#2b4257;border:none;color:white;font-weight:bold;margin-bottom:5px;'>編輯訂單</button>
              </a>
              <form action='orderfunc.php' method='post'>
                <input type='hidden' name='id' value='".$row['order_id']."'>
                <input type='hidden' name='func' value='done'>
                <input type='submit'  class='btn btn-warning btn-xs btn-delete' style='background-color:#88a9c3;border:none;color:white;font-weight:bold' value = '完成訂單'>
              </form>
            </td>
            </tr>";
          }
          elseif($row['complete'] == 4){
            echo "
            <td>訂單已逾期</td>
            <td>
              已通知取餐
            </td>
            <td>
              <a href='' data-bs-toggle='modal' data-bs-target='#exampleModal".$row['order_id']."' style='text-decoration: none; color: white;'>
                <button class='btn btn-info btn-xs btn-edit' style='background-color:#2b4257;border:none;color:white;font-weight:bold;margin-bottom:5px;'>編輯訂單</button>
              </a>
              <form action='orderfunc.php' method='post'>
                <input type='hidden' name='id' value='".$row['order_id']."'>
                <input type='hidden' name='func' value='expire'>
                <input type='hidden' name='user' value='".$row['user_id']."'>
                <input type='submit'  class='btn btn-danger btn-xs btn-delete' style='background-color:#c4391d;border:none;color:white;font-weight:bold' value = '逾期訂單'>
              </form>
            </td>
            </tr>";
          }
          #Modal
          echo"
          <div class='modal fade' id='exampleModal".$row['order_id']."' tabindex='-1' aria-labelledby='exampleModalLabel'
          aria-hidden='true'>
            <div class='modal-dialog modal-dialog-centered modal-dialog-scrollable'>
              <div class='modal-content' style='overflow:auto;'>
                <div class='modal-header'>
                  <h5 class='modal-title' id='exampleModalLabel'>編輯｜訂單編號：".$row['order_id']."</h5>
                  
                  <button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
                </div>
                <div class='text-body'>
                  <br>
                  <form action='updateorder.php' method = 'post'>
                    <input type='hidden' name = 'page' value = 'unfinished'>
                    <input type='hidden' name = 'order_id' value = '".$row['order_id']."'>
              ";
                    $sqltemp = "SELECT * FROM `orderdetail` WHERE order_id ='".$row['order_id']."'";
                    if($rstemp = mysqli_query($con, $sqltemp)){
                      while($rowtemp = mysqli_fetch_assoc($rstemp)){
                        $sqlitem = "SELECT `name` FROM item WHERE item_id = ".$rowtemp['item_id']."";
                        $rsitem = mysqli_query($con, $sqlitem);
                        $rowitem = mysqli_fetch_assoc($rsitem);
                        $item_name = $rowitem['name'];
                        echo"
                        <input type='hidden' name = 'id[]' value = '".$rowtemp['det_id']."'>
                        <h5>&nbsp".$item_name."</h5><br>
                        <div class='form-check'>修改數量&nbsp
                          <input type='number' class='formnumber' id='exampleFormControlInput' name = 'amount[]' min='0' max='10' value = '".$rowtemp['amount']."' required style='width: 90px;'>
                        </div><br>
                        <div class='form-check'>修改備註&nbsp
                          <input type='text' id='exampleFormControlInput' name = 'note[]' value = '".$rowtemp['note']."'>
                        </div><br>
                        ";
                      }
                    }
                    echo"
                    <br>
                    <div class='modal-footer'>
                      <button type='button' class='btn btn-secondary' data-bs-dismiss='modal'>取消</button>
                      <input type='submit' class='btn btn-primary' style='background-color:#2b4257;border:none' value='更新訂單'>
                    </div>
                    
                  </form>
                </div>
              </div>
            </div>
          </div>
            ";
        }
      }
      if($item_count == 0){
        echo "<center><h1>所有訂單已完成</h1></center>";
      }
    ?>
    
   
  </tbody>
</table>
</table>


</div>
</div>
<footer class="bg-dark text-center text-white">
  <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
    © 方禾食呂後臺管理系統
  </div>
</footer>

<!--<script type="text/javascript" src="單位年薪js.js"></script>-->
<script src="js/jquery-3.4.1.min.js"></script>
  <!-- popper js -->
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
    integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
    </script>
  <!-- bootstrap js -->
  <script src="js/bootstrap.js"></script>
  <!-- owl slider -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js">
  </script>
  <!-- isotope js -->
  <script src="https://unpkg.com/isotope-layout@3.0.4/dist/isotope.pkgd.min.js"></script>
  <!-- nice select -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-nice-select/1.1.0/js/jquery.nice-select.min.js"></script>
  <!-- custom js -->
  <script src="js/custom.js"></script>
  <!-- Google Map -->
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCh39n5U-4IoWpsVGUHWdqB6puEkhRLdmI&callback=myMap">
  </script>
  <!-- End Google Map -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ"
    crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.1/dist/umd/popper.min.js"
    integrity="sha384-W8fXfP3gkOKtndU4JGtKDvXbO53Wy8SZCQHczT5FMiiqmQfUpWbYdTil/SxwZgAN"
    crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js"
    integrity="sha384-skAcpIdS7UcVUC05LJ9Dxay8AXcDYfBJqt1CJ85S/CFujBsIzCIv+l9liuYLaMQ/"
    crossorigin="anonymous"></script>

    <?php 
    include('notification.php');
    if(isset($_GET['message'])){
      if(isset($_SESSION['type'])){
        echo "<script>notify('".$_SESSION['type']."', '".$_GET['message']."')</script>";
      }
    }
    ?>
</body>
</html>
<?php
  mysqli_close($con);
?>