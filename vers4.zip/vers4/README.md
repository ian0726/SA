# SA Sprint Review 3 Progress

sa6是這次新的檔案 大部分都整合好了 <br>
資料庫有更新喔 (seating, cart, orderdetail, 可能還有其他的) <br>
請大家測試看看有沒有bug <br><br>
代辦事項：<br>
修改前端 （配色 <br>
剩餘文件<br>
